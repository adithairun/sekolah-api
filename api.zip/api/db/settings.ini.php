;<?php return; ?>
[SQL]
host = localhost
user = root
password = 123
dbname = sekolah_api
